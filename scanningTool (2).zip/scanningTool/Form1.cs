using System;
using System.Windows.Forms;
using System.Management; // For accessing WMI services
using System.Diagnostics; // For EventLog and Process
using System.Net.NetworkInformation; // For NetworkInterface
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using OpenAI.Managers;
using OpenAI;
using OpenAI.ObjectModels;
using OpenAI.ObjectModels.RequestModels;



namespace scanningTool // Use your project's namespace
{
   class pgrrmrg
    {
        static async Task Main(string[] args)
        {
            var service = new OpenAIService(new OpenAiOptions
            {
                ApiKey = "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"
            });
            service.SetDefaultModelId(Models.ChatGpt3_5Turbo);

            var messages = new List<ChatMessage>
            {
                //...
            };

            var req = new ChatCompletionCreateRequest
            {
                Messages = messages,
                N = 1,
                //MaxTokens = 2000,
                //FrequencyPenalty = 2.0f,
                //Temperature = 0.1f
            };

            var res = await service.ChatCompletion.CreateCompletion(req);

            if (res.Successful)
            {
                var resultContent = res.Choices.First().Message.Content;
                Console.WriteLine(resultContent);
            }
        }
    }

    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
            
            
            // Ensure you have buttons named btnCheckUptime, btnFindPcAge, btnCheckSystemErrors, 
            // btnFindWarnings, btnFindNetworkInfo, and btnDiskImage in your form, and they are
            // wired to the corresponding event handlers.


            // Create and configure the TableLayoutPanel
            TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
            tableLayoutPanel.Dock = DockStyle.Fill;
            tableLayoutPanel.ColumnCount = 2;
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200)); // Buttons column
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); // TextBox column
            tableLayoutPanel.RowCount = 1;

            // Create a Panel for buttons to ensure they don't stretch vertically
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Fill; // Fill the first cell of the table

            // Add buttons to the panel
            // Adjust locations as needed, assuming 10px margin and 10px between buttons
            btnCheckDiskHealth.Location = new Point(10, 10);
            btnFindPcAge.Location = new Point(10, 70); // 50px height + 10px margin
            btnCheckSystemErrors.Location = new Point(10, 130); // Another 50px height + 10px margin
            btnFindWarnings.Location = new Point(10, 190);
            btnFindNetworkInfo.Location = new Point(10, 250);
            btnDiskImage.Location = new Point(10, 310);
            btnCheckUptime.Location = new Point(10, 370);

            // Add buttons to the button panel
            buttonPanel.Controls.Add(btnCheckDiskHealth);
            buttonPanel.Controls.Add(btnFindPcAge);
            buttonPanel.Controls.Add(btnCheckSystemErrors);
            buttonPanel.Controls.Add(btnFindWarnings);
            buttonPanel.Controls.Add(btnFindNetworkInfo);
            buttonPanel.Controls.Add(btnDiskImage);
            buttonPanel.Controls.Add(btnCheckUptime);

            // Configure the textBoxOutput
            textBoxOutput.Dock = DockStyle.Fill;

            // Add the button panel and textBoxOutput to the tableLayoutPanel
            tableLayoutPanel.Controls.Add(buttonPanel, 0, 0); // First cell
            tableLayoutPanel.Controls.Add(textBoxOutput, 1, 0); // Second cell, it will fill the rest of the space

            // Add the tableLayoutPanel to the form's controls
            this.Controls.Add(tableLayoutPanel);
        }

        // This method is correctly wired to a button intended to check system uptime.
        private void btnCheckUptime_Click(object sender, EventArgs e)
        {
            TimeSpan uptime = TimeSpan.FromMilliseconds(Environment.TickCount64);
            textBoxOutput.Clear();
            textBoxOutput.AppendText($"System Uptime: {uptime.Days} days, {uptime.Hours} hours, {uptime.Minutes} minutes{Environment.NewLine}");
        }

        // This method should be wired to a button intended to find the PC age.
        private void btnFindPcAge_Click(object sender, EventArgs e)
        {
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_OperatingSystem");
            foreach (ManagementObject queryObj in searcher.Get())
            {
                DateTime lastBootUp = ManagementDateTimeConverter.ToDateTime(queryObj["InstallDate"].ToString());
                TimeSpan age = DateTime.Now - lastBootUp;
                textBoxOutput.Clear();
                textBoxOutput.AppendText($"PC Age: {age.Days / 365} years, {(age.Days % 365) / 30} months{Environment.NewLine}");
            }
        }

        // This method should be wired to a button intended to check system errors.

        private void btnCheckSystemErrors_Click(object sender, EventArgs e)
        {
            textBoxOutput.Clear();
            textBoxOutput.AppendText($"Checking System Errors...\n");
            EventLog systemLog = new EventLog("System");
            foreach (EventLogEntry entry in systemLog.Entries)
            {
                if (entry.EntryType == EventLogEntryType.Error)
                {
                    textBoxOutput.AppendText($"{Environment.NewLine}Error: {entry.Source} - {entry.Message}\n");
                }
            }
        }
        // This method should be wired to a button intended to find warnings.
        private void btnFindWarnings_Click(object sender, EventArgs e)
        {
            var warningsBySource = new Dictionary<string, List<EventLogEntry>>();

            EventLog systemLog = new EventLog("System");
            var warningEntries = systemLog.Entries.Cast<EventLogEntry>()
                                    .Where(entry => entry.EntryType == EventLogEntryType.Warning)
                                    .OrderByDescending(entry => entry.TimeGenerated);

            foreach (var entry in warningEntries)
            {
                if (!warningsBySource.ContainsKey(entry.Source))
                {
                    warningsBySource[entry.Source] = new List<EventLogEntry>();
                }
                if (warningsBySource[entry.Source].Count < 5) // Limit to the 5 most recent warnings per source
                {
                    warningsBySource[entry.Source].Add(entry);
                }
            }

            // Clear existing text
            textBoxOutput.Clear();

            // Display warnings categorized by source
            foreach (var source in warningsBySource.Keys)
            {
                textBoxOutput.AppendText($"Warnings from {source} (showing up to 5 recent):\n");
                foreach (var warning in warningsBySource[source])
                {
                    // Display date and a truncated version of the message for each warning
                    string truncatedMessage = warning.Message.Length > 100 ? warning.Message.Substring(0, 100) + "..." : warning.Message;
                    textBoxOutput.AppendText($"  - {warning.TimeGenerated}: {truncatedMessage}\n");
                }
                textBoxOutput.AppendText("\n"); // Add a blank line for separation
            }
        }


        // This method should be wired to a button intended to find network information.
        private void btnFindNetworkInfo_Click(object sender, EventArgs e)
        {
            var upInterfaces = new List<string>();
            var downInterfaces = new List<string>();

            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                // Get IP addresses
                string ipAddresses = String.Join(", ", ni.GetIPProperties().UnicastAddresses
                    .Select(ipInfo => ipInfo.Address.ToString())
                    .Where(ip => ip.Contains('.'))); // Filter to include only IPv4 addresses

                string interfaceInfo = $"Name: {ni.Name}, Status: {ni.OperationalStatus}, IP: {(String.IsNullOrEmpty(ipAddresses) ? "None" : ipAddresses)}";

                if (ni.OperationalStatus == OperationalStatus.Up)
                {
                    upInterfaces.Add(interfaceInfo);
                }
                else
                {
                    downInterfaces.Add(interfaceInfo);
                }
            }

            // Clear existing text
            textBoxOutput.Clear();

            // Display summary counts
            textBoxOutput.AppendText($"Network Interfaces Summary: {Environment.NewLine}");
            textBoxOutput.AppendText($"- Up: {upInterfaces.Count}{Environment.NewLine}");
            textBoxOutput.AppendText($"- Down: {downInterfaces.Count}{Environment.NewLine}{Environment.NewLine}");

            // Display Up interfaces
            textBoxOutput.AppendText("Interfaces Up:" + Environment.NewLine);
            foreach (var upInterface in upInterfaces)
            {
                textBoxOutput.AppendText($"  � {upInterface}{Environment.NewLine}");
            }

            // Provide some spacing between sections
            textBoxOutput.AppendText(Environment.NewLine);

            // Display Down interfaces with emphasis
            textBoxOutput.AppendText("Interfaces Down (Check these):" + Environment.NewLine);
            foreach (var downInterface in downInterfaces)
            {
                textBoxOutput.AppendText($"  � {downInterface}{Environment.NewLine}");
            }
        }


        // This method should be wired to a button intended to create a disk image.
        // Ensure you replace "disk-imaging-tool.exe" and "arguments-for-imaging" with actual values.
        private async void btnDiskImage_Click(object sender, EventArgs e)
        {
            string dumpItPath = @"C:\Users\peiwa\Desktop\Bachelor-prosjekt New try\scanningTool\DumpIt.exe";
            string outputFolderPath = @"C:\Users\peiwa\Desktop\Bachelor-prosjekt New try\scanningTool\DumpIt Files";

            // Ensure the output folder exists
            Directory.CreateDirectory(outputFolderPath);

            // Inform the user that the disk image process is starting
            textBoxOutput.Clear();
            textBoxOutput.AppendText($"Creating disk image... Please wait.\n");

            ProcessStartInfo startInfo = new ProcessStartInfo()
            {
                FileName = dumpItPath,
                UseShellExecute = true,  // Required for Verb = "runas"
                Verb = "runas",  // Request elevation
                WorkingDirectory = outputFolderPath  // Set the working directory to where you want the .raw file saved
            };

            try
            {
                using (Process process = new Process { StartInfo = startInfo })
                {
                    process.Start();
                    await Task.Run(() => process.WaitForExit()); // Wait for the process to exit asynchronously

                    // Modified retry mechanism to pick the newest file
                    int retries = 20;
                    FileInfo newestRawFile = null;
                    while (retries > 0)
                    {
                        var rawFiles = new DirectoryInfo(outputFolderPath)
                                       .EnumerateFiles("*.raw")
                                       .OrderByDescending(f => f.CreationTime)
                                       .FirstOrDefault();

                        if (rawFiles != null)
                        {
                            newestRawFile = rawFiles;
                            break;
                        }
                        else
                        {
                            retries--;
                            await Task.Delay(2000); // Wait for 2 seconds before retrying
                        }
                    }

                    if (newestRawFile != null)
                    {
                        this.Invoke(new Action(() =>
                        {
                            textBoxOutput.AppendText($"{Environment.NewLine}Disk image successfully saved: {Environment.NewLine} {newestRawFile.FullName}\n");
                        }));
                    }
                    else
                    {
                        this.Invoke(new Action(() =>
                        {
                            textBoxOutput.AppendText("An error occurred during disk image creation or no disk image was found after multiple retries.\n");
                        }));
                    }
                }
            }
            catch (Exception ex)
            {
                // Catch and display any exceptions that occur during the process start
                this.Invoke(new Action(() =>
                {
                    textBoxOutput.AppendText($"Failed to start DumpIt.exe: {ex.Message}\n");
                }));
            }
        }




        // This method seems to be intended for checking hard disk health.
        // Ensure you have a button named button1 or rename it to something more descriptive and wire this method.
        private void btnCheckDiskHealth_Click(object sender, EventArgs e)
        {
            textBoxOutput.Clear();
            textBoxOutput.AppendText($"Checking Hard Disk Health...\n");
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
                foreach (ManagementObject disk in searcher.Get())
                {
                    string deviceId = disk["DeviceID"].ToString();
                    string model = disk["Model"]?.ToString() ?? "Unknown Model";
                    string status = disk["Status"]?.ToString() ?? "Unknown Status";
                    textBoxOutput.AppendText($"{Environment.NewLine}Disk: {deviceId}{Environment.NewLine} ({model}) {Environment.NewLine}- Status: {status}\n");
                }
            }
            catch (Exception ex)
            {
                textBoxOutput.AppendText($"Error checking hard disk health: {ex.Message}\n");
            }
        }
    }
}
