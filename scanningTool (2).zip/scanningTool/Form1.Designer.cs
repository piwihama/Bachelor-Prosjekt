﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace scanningTool
{
    partial class Form1
    {

        private System.ComponentModel.IContainer components = null;
        private TextBox textBoxOutput;
        private Button btnCheckDiskHealth;
        private Button btnFindPcAge;
        private Button btnCheckSystemErrors;
        private Button btnFindWarnings;
        private Button btnFindNetworkInfo;
        private Button btnDiskImage;
        private Button btnCheckUptime;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {

            components = new System.ComponentModel.Container();
            AutoScaleMode = AutoScaleMode.Font;
            Text = "Scanning Tool";
            ClientSize = new Size(800, 450);
            BackColor = Color.FromArgb(37, 37, 38);

            textBoxOutput = new TextBox
            {
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Location = new Point(301, 23),
                Size = new Size(409, 381),
                BackColor = Color.FromArgb(30, 30, 30),
                ForeColor = Color.LightGreen,
                Font = new Font("Consolas", 10F)
            };
            Controls.Add(textBoxOutput);

            btnCheckDiskHealth = CreateButton("Check Disk Health", 27, 23);
            btnFindPcAge = CreateButton("Find PC Age", 27, 83);
            btnCheckSystemErrors = CreateButton("Check System Errors", 27, 143);
            btnFindWarnings = CreateButton("Find Warnings", 27, 203);
            btnFindNetworkInfo = CreateButton("Find Network Info", 27, 263);
            btnDiskImage = CreateButton("Create Disk Image", 27, 323);
            btnCheckUptime = CreateButton("Check Uptime", 27, 383);
            btnCheckDiskHealth.Click += btnCheckDiskHealth_Click;
            btnFindPcAge.Click += btnFindPcAge_Click;
            btnCheckSystemErrors.Click += btnCheckSystemErrors_Click;
            btnFindWarnings.Click += btnFindWarnings_Click;
            btnFindNetworkInfo.Click += btnFindNetworkInfo_Click;
            btnDiskImage.Click += btnDiskImage_Click;
            btnCheckUptime.Click += btnCheckUptime_Click;

            Controls.AddRange(new Control[] { btnCheckDiskHealth, btnFindPcAge, btnCheckSystemErrors, btnFindWarnings, btnFindNetworkInfo, btnDiskImage, btnCheckUptime });
        }

        private Button CreateButton(string text, int x, int y)
        {
            Button button = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(165, 40),
                BackColor = Color.FromArgb(45, 45, 48),
                ForeColor = Color.WhiteSmoke,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold)
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(51, 51, 55);
            return button;
        }
    }
}
